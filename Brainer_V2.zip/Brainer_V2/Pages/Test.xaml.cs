﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Brainer_V2.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Test : Page
    {
        string qqq1 = "What fkies when it's born, lies when it's alive. and runs when it's dead?";
        string qa1a = "A grain of sand";
        string qa1b = "A an eaglet";
        string qa1c = "A snowflake";// right
        string qa1d = "A fruit fly";

        string qqq2 = "If POST is 1234 and FLIRT is 56784, what is FROST?";
        string qa2a = "58234";//right
        string qa2b = "58243";
        string qa2c = "52384";
        string qa2d = "43285";

        string qqq3 = "I start with M, end with x, and have never ending amount of letters. What am I?";
        string qa3a = "Mix";
        string qa3b = "Mailbox";//right
        string qa3c = "Multyplex";
        string qa3d = "A teacher in TriOS";

        string qqq4 = "Which word best expresses the meaning of: 'Reassure'?";
        string qa4a = "Proffer";
        string qa4b = "Hearten";// right
        string qa4c = "Induce";
        string qa4d = "Submit";

        public int qcounter = 0;
        public int num1;
        public int num2;
        public int rightAns = 0;
        public int rightAnsSum = 0;
        public int rightAnsMulti = 0;
        public int rightQ = 0;
        public Test()
        {
            this.InitializeComponent();

            qcounter++;
            Random random = new Random();
            num1 = random.Next(1, 101);
            num2 = random.Next(1, 101);
            n1.Text = num1.ToString();
            n2.Text = num2.ToString();
            Total.Text = qcounter.ToString();
            endTest.Visibility = Visibility.Visible;
            endTest2.Visibility = Visibility.Collapsed;
        }


        private void Calc(object sender, RoutedEventArgs e)
        {
            if (qcounter < 5)
            {
                checkSum();
            }

            if (qcounter > 4 && qcounter < 9)
            {
                Level.Text = "Second Level";
                op.Text = "X";
                multip();
            }
            qcounter++;
            Total.Text = qcounter.ToString();

            if (qcounter > 8)
            {
                endTest.Visibility = Visibility.Collapsed;
                endTest2.Visibility = Visibility.Visible;
                questios();
            }
        }

        public void questios()
        {
            switch (qcounter)
            {
                case 9:
                    que1.Visibility = Visibility.Visible;
                    qq1.Text = qqq1;
                    a11.Content = qa1a;
                    a21.Content = qa1b;
                    a31.Content = qa1c;//
                    a41.Content = qa1d;
                    break;


                case 10:
                    que1.Visibility = Visibility.Collapsed;
                    que2.Visibility = Visibility.Visible;
                    qq2.Text = qqq2;
                    a12.Content = qa2a;//
                    a22.Content = qa2b;
                    a32.Content = qa2c;
                    a42.Content = qa2d;
                    break;


                case 11:
                    que2.Visibility = Visibility.Collapsed;
                    que3.Visibility = Visibility.Visible;
                    qq3.Text = qqq3;
                    a13.Content = qa3a;
                    a23.Content = qa3b;//
                    a33.Content = qa3c;
                    a43.Content = qa3d;
                    break;

                case 12:
                    que3.Visibility = Visibility.Collapsed;
                    que4.Visibility = Visibility.Visible;
                    qq4.Text = qqq4;
                    a14.Content = qa4a;
                    a24.Content = qa4b;//
                    a34.Content = qa4c;
                    a44.Content = qa4d;
                    break;
                default:
                    break;
            }
            qcounter++;

            if (qcounter > 13)
            {
                getResult();
            }
        }

        public void MCQwrong(object sender, RoutedEventArgs e)
        {

            Total.Text = qcounter.ToString();
            RightAns.Text = rightAns.ToString();
            questios();
        }
        public void MCQright(object sender, RoutedEventArgs e)
        {

            rightAns++;
            rightQ++;
            Total.Text = qcounter.ToString();
            RightAns.Text = rightAns.ToString();
            questios();
        }

        public void checkSum()
        {
            int sum = num1 + num2;
            int Answer = int.Parse(answer.Text);
            if (Answer == sum)
            {

                rightAns++;
                rightAnsSum++;
                RightAns.Text = rightAns.ToString();
            }
            create();
        }

        public void multip()
        {

            int multy = num1 * num2;
            int Answer = int.Parse(answer.Text);
            if (Answer == multy)
            {
                rightAns++;
                rightAnsMulti++;
                RightAns.Text = rightAns.ToString();
            }
            create();

        }

        public void create()
        {
            Random random = new Random();
            num1 = random.Next(1, 101);
            num2 = random.Next(1, 101);
            n1.Text = num1.ToString();
            n2.Text = num2.ToString();
        }

        public void getResult()
        {
            SumResult.Text = rightAnsSum.ToString();
            MulResult.Text = rightAnsMulti.ToString();
            QueResult.Text = rightQ.ToString();
            if (rightAnsSum < 4)
            {
                SumAdv.Visibility = Visibility.Visible;
            }
            if (rightAnsMulti < 4)
            {
                MulAdv.Visibility = Visibility.Visible;
            }
            if (rightQ < 4)
            {
                LogicAdv.Visibility = Visibility.Visible;
            }
            TotalResult.Text = rightAns.ToString();
            alltests.Visibility = Visibility.Collapsed;
            result.Visibility = Visibility.Visible;
        }

        private void Reset(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Pages.Test));
        }
        private void Info(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Pages.Info));
        }
        private void ContactUs(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Pages.ContactUs));
        }
    }
}
