﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.Email;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Brainer_V2.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ContactUs : Page
    {
        public ContactUs()
        {
            this.InitializeComponent();
        }


        private void send(object sender, RoutedEventArgs e)
        {
            sendEmail();
        }

        public async Task sendEmail()
        {
            string username = name.Text;

            string useremail = email.Text;

            string subject = sub.Text;

            string messgae = msg.Text;


            EmailMessage em = new EmailMessage();

            em.To.Add(new EmailRecipient("info@brainer.com"));

            string emailBody = " This email from  " + username + "regarding   " + subject + "from " + useremail + " of thr following " + messgae;
            em.Body = emailBody;
            em.Subject = subject;
            await EmailManager.ShowComposeNewEmailAsync(em);

        }

            private void Reset(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Pages.Test));
        }
        private void Info(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Pages.Info));
        }
        private void Contact_Us(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Pages.ContactUs));
        }

    }
}
